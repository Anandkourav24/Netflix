# MenuPro — Restaurant Menu Management System

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in a modern browser, or use VS Code's Live Server extension.
3. Sign in with any valid email address and any password. Choose Admin, Manager, or Staff.
4. Data is saved in your browser using `localStorage`.

## Files
- `index.html` — page structure and forms
- `style.css` — responsive rose-themed UI and dark mode
- `script.js` — sample data, CRUD operations, filters, reports, snapshots, and charts

## Notes
- Frontend-only internship/demo project. No database or server is used.
- Login/register is simulated and is not secure production authentication.
- Analytics uses illustrative sample data; connect real sales data for genuine reports.
- Menu photos can be supplied with an image URL in the item editor.
- Browser localStorage is device/browser-specific. Clearing browser data may erase changes.
